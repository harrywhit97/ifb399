<?php
$metadata['https://example.com'] = array(
    'SingleSignOnService'  => 'identity.example.com/',
    'SingleLogoutService'  => 'identity.example.com',
    'certificate'          => 'cert.pem',
);
