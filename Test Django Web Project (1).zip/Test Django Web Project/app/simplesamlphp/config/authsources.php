<?php
$config = array(

    /* This is the name of this authentication source, and will be used to access it later. */
    'default-sp' => array(
        'saml:SP',
    ),

?>
