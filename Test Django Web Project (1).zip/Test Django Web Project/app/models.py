"""
Definition of models.
"""

from django.db import models

